module VagrantPlugins
  module Cachier
    VERSION = "1.2.1"
  end
end
